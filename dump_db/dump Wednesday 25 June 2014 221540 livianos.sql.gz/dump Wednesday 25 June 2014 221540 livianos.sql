-- Dump de la Base de Datos
-- Fecha: Wednesday 25 June 2014 - 15:15:41
--
-- Version: 1.1.1, del 18 de Marzo de 2014, https://twitter.com/cesar_garces
-- Soporte y Updaters: https://twitter.com/cesar_garces
--
-- Host: `localhost`    Database: `prueba`
-- ------------------------------------------------------
-- Server version	5.5.32

--
-- Table structure for table `bodega`
--

DROP TABLE IF EXISTS bodega;
CREATE TABLE `bodega` (
  `codigo` int(10) NOT NULL,
  `nombre` longtext COLLATE utf8_spanish_ci NOT NULL,
  `unidad` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `tipo` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `especificacion_1` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `especificacion_2` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `valor` int(11) NOT NULL,
  `imagen` varchar(150) COLLATE utf8_spanish_ci DEFAULT NULL,
  `minimo` int(11) NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `bodega`
--

LOCK TABLES bodega WRITE;
UNLOCK TABLES;


--
-- Table structure for table `cotizacion`
--

DROP TABLE IF EXISTS cotizacion;
CREATE TABLE `cotizacion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_cliente` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `empresa_cliente` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `asunto` varchar(300) COLLATE utf8_spanish_ci NOT NULL,
  `obra` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `cod_obra` int(11) NOT NULL,
  `producto` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `cod_prod_cot` int(11) NOT NULL,
  `descripcion` varchar(500) COLLATE utf8_spanish_ci NOT NULL,
  `unidad` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `cantidad` int(11) NOT NULL,
  `valor_unidad` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `cotizacion`
--

LOCK TABLES cotizacion WRITE;
INSERT INTO cotizacion VALUES('1', 'cesar', 'alicanr', 'cambio de muro', 'atillar', '300', 'drywall', '1', 'cambio de artillador trifilar a 45% de 3\"', 'U/N', '5', '1500', '7000');
INSERT INTO cotizacion VALUES('2', 'cesar', 'alicanr', 'cambio de muro', 'atillar', '300', 'drywall', '1', 'cambio de artillador trifilar a 45% de 3\"', 'U/N', '5', '1500', '7000');
UNLOCK TABLES;


--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS customer;
CREATE TABLE `customer` (
  `idCustomer` int(11) NOT NULL AUTO_INCREMENT,
  `nombreCust` varchar(50) COLLATE utf8_spanish_ci NOT NULL DEFAULT '0',
  `cedNit` varchar(50) COLLATE utf8_spanish_ci NOT NULL DEFAULT '0',
  `direccion` varchar(150) COLLATE utf8_spanish_ci NOT NULL DEFAULT '0',
  `Tel` varchar(20) COLLATE utf8_spanish_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`idCustomer`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `customer`
--

LOCK TABLES customer WRITE;
INSERT INTO customer VALUES('1', 'carlos', '1548977', 'alle 123', '3104589654');
INSERT INTO customer VALUES('2', 'cesar', '34578944', 'floresta', '30145874554');
UNLOCK TABLES;


--
-- Table structure for table `entrada`
--

DROP TABLE IF EXISTS entrada;
CREATE TABLE `entrada` (
  `codentr` int(11) NOT NULL AUTO_INCREMENT,
  `prov` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `codprov` int(11) NOT NULL,
  `obra` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `codobra` int(11) NOT NULL,
  `nfac` int(11) NOT NULL,
  `fecha` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `codmat` int(11) NOT NULL,
  `descrip` varchar(150) COLLATE utf8_spanish_ci NOT NULL,
  `unidad` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `valor` int(11) NOT NULL,
  `cantmat` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `tipo_entrada` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`codentr`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `entrada`
--

LOCK TABLES entrada WRITE;
UNLOCK TABLES;


--
-- Table structure for table `material`
--

DROP TABLE IF EXISTS material;
CREATE TABLE `material` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` int(11) NOT NULL,
  `descripcion` varchar(150) COLLATE utf8_spanish_ci NOT NULL,
  `unidad` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `precio_unidad` int(11) NOT NULL,
  `proov` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `cod_proov` int(11) NOT NULL,
  `fecha_costo` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `imagen` varchar(150) COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `material`
--

LOCK TABLES material WRITE;
INSERT INTO material VALUES('11', '11', 'Placa de drywall 1/2', 'un', '16500', 'Sudrywall', '1', '2014/06/20', '../bodega/img/mat/');
INSERT INTO material VALUES('12', '12', 'Placa SB de 8mm', 'un', '40000', 'Sudrywall', '1', '2014/06/20', '../bodega/img/mat/');
UNLOCK TABLES;


--
-- Table structure for table `mod_profile`
--

DROP TABLE IF EXISTS mod_profile;
CREATE TABLE `mod_profile` (
  `idmod_prof` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idmodule` int(11) DEFAULT NULL,
  `idProfile` int(11) DEFAULT NULL,
  PRIMARY KEY (`idmod_prof`),
  KEY `fk1` (`idmodule`),
  KEY `fk2` (`idProfile`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `mod_profile`
--

LOCK TABLES mod_profile WRITE;
UNLOCK TABLES;


--
-- Table structure for table `modules`
--

DROP TABLE IF EXISTS modules;
CREATE TABLE `modules` (
  `idmodule` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `codeModule` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `nameModule` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `descModule` varchar(250) COLLATE utf8_spanish_ci NOT NULL,
  `dateModule` date NOT NULL,
  `statusModu` set('Enabled','Disabled') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`idmodule`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `modules`
--

LOCK TABLES modules WRITE;
UNLOCK TABLES;


--
-- Table structure for table `obra`
--

DROP TABLE IF EXISTS obra;
CREATE TABLE `obra` (
  `codigo` int(11) NOT NULL,
  `nombre` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `responsable` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `telefono` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `celular` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `obra`
--

LOCK TABLES obra WRITE;
UNLOCK TABLES;


--
-- Table structure for table `profiles`
--

DROP TABLE IF EXISTS profiles;
CREATE TABLE `profiles` (
  `idProfile` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `codeProfi` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `nameProfi` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `descProfi` varchar(250) COLLATE utf8_spanish_ci NOT NULL,
  `dateProfi` date NOT NULL,
  `statusPro` set('Enabled','Disabled') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`idProfile`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `profiles`
--

LOCK TABLES profiles WRITE;
INSERT INTO profiles VALUES('2', '01', 'Admin', 'Super usuario administrador de aplicacion', '2014-01-15', 'Enabled');
INSERT INTO profiles VALUES('3', '02', 'Gerente', 'Cotizaciones , cartera y verificaci', '2014-01-16', 'Enabled');
INSERT INTO profiles VALUES('4', '03', 'Administrador', 'Analisis de mercado, compras, despacho de materiales, pago de materiales', '2014-01-17', 'Enabled');
INSERT INTO profiles VALUES('5', '04', 'Obras', 'Revisi', '2014-01-19', 'Enabled');
INSERT INTO profiles VALUES('6', '05', 'Bodega', 'Manejo de inventari', '2014-01-20', 'Enabled');
INSERT INTO profiles VALUES('7', '06', 'visita', 'es un visitante', '2014-01-28', 'Enabled');
INSERT INTO profiles VALUES('8', 'nada', 'aaaa', 'aaa', '2014-01-31', 'Enabled');
UNLOCK TABLES;


--
-- Table structure for table `proveedor`
--

DROP TABLE IF EXISTS proveedor;
CREATE TABLE `proveedor` (
  `codigo` int(11) NOT NULL,
  `nombre` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `contacto` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `telefono` double DEFAULT NULL,
  `celular` double DEFAULT NULL,
  `email` varchar(150) COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `proveedor`
--

LOCK TABLES proveedor WRITE;
INSERT INTO proveedor VALUES('1', 'Sudrywall', 'Ismael Henao', '3162050', '3108329863', 'ihenaolo@gmail.com');
INSERT INTO proveedor VALUES('2', 'EYP', 'Jorge vendedor', '4447529', '3117628963', 'hucaye@hotmail.com');
INSERT INTO proveedor VALUES('3', 'Marped', 'Lina Vendedora', '0', '0', '');
INSERT INTO proveedor VALUES('4', 'Construdrywall', 'Andres', '0', '0', '');
INSERT INTO proveedor VALUES('5', 'Perfiles Brian', 'Brian Vendedor', '0', '0', '');
INSERT INTO proveedor VALUES('6', 'Matexa', '', '0', '0', '');
INSERT INTO proveedor VALUES('7', 'Deposito ADA', 'Gustavo Admon', '0', '0', '');
INSERT INTO proveedor VALUES('8', 'Adiela lombana-Cali', '', '0', '0', '');
UNLOCK TABLES;


--
-- Table structure for table `role_user`
--

DROP TABLE IF EXISTS role_user;
CREATE TABLE `role_user` (
  `idRolUs` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idUsers` int(11) NOT NULL,
  `idRole` int(11) NOT NULL,
  PRIMARY KEY (`idRolUs`),
  KEY `fk1` (`idUsers`),
  KEY `fk2` (`idRole`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `role_user`
--

LOCK TABLES role_user WRITE;
INSERT INTO role_user VALUES('2', '1', '1');
UNLOCK TABLES;


--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS roles;
CREATE TABLE `roles` (
  `idRole` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `codeRole` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `nameRole` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `descRole` longtext COLLATE utf8_spanish_ci NOT NULL,
  `statRole` set('Enabled','Disabled') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`idRole`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `roles`
--

LOCK TABLES roles WRITE;
INSERT INTO roles VALUES('2', '01admin', 'admin', 'operador super usuario', 'Enabled');
INSERT INTO roles VALUES('3', '02gerente', 'gerente', 'operador gerente', 'Enabled');
UNLOCK TABLES;


--
-- Table structure for table `salida`
--

DROP TABLE IF EXISTS salida;
CREATE TABLE `salida` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orden` int(11) NOT NULL,
  `obra` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `codobra` int(11) NOT NULL,
  `despacho` int(11) NOT NULL,
  `fecha` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `codmat` int(11) NOT NULL,
  `descripcion` varchar(150) COLLATE utf8_spanish_ci NOT NULL,
  `unidad` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `valor` int(11) NOT NULL,
  `cantmat` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `salida`
--

LOCK TABLES salida WRITE;
UNLOCK TABLES;


--
-- Table structure for table `user_pro`
--

DROP TABLE IF EXISTS user_pro;
CREATE TABLE `user_pro` (
  `idUserPro` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idProfile` int(11) NOT NULL,
  `idUsers` int(11) NOT NULL,
  PRIMARY KEY (`idUserPro`),
  KEY `fk1` (`idProfile`),
  KEY `fk2` (`idUsers`)
) ENGINE=MyISAM AUTO_INCREMENT=66 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `user_pro`
--

LOCK TABLES user_pro WRITE;
INSERT INTO user_pro VALUES('65', '6', '15');
INSERT INTO user_pro VALUES('58', '2', '1');
UNLOCK TABLES;


--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS users;
CREATE TABLE `users` (
  `idUsers` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `loginUsers` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `passUsers` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `idprofile` int(11) NOT NULL,
  `emailUser` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `idActiveCode` varchar(500) COLLATE utf8_spanish_ci DEFAULT NULL,
  `imagen` longtext COLLATE utf8_spanish_ci,
  `idexistindb` int(11) NOT NULL,
  `nameProfi` enum('admin','gerente') COLLATE utf8_spanish_ci DEFAULT NULL,
  `statusUsers` enum('enabled','disabled') COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`idUsers`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `users`
--

LOCK TABLES users WRITE;
INSERT INTO users VALUES('1', 'admin', 'admin', '2', '', '1', '../user/img/favicon.png', '0', 'admin', 'enabled');
INSERT INTO users VALUES('15', 'ASISTENTE', 'asistente', '6', 'asistente@livianos.co', '1', '../user/img/favicon.png', '1', 'admin', 'enabled');
UNLOCK TABLES;



-- Dump de la Base de Datos Completo.